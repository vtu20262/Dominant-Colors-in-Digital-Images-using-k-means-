//
//  Use this file to import your target's public headers that you would like to expose to Swift.
//

#include <stdint.h>
extern uint64_t dispatch_benchmark(size_t count, void (^block)(void));
